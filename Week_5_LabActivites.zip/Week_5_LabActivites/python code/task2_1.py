import cv2

image = cv2.imread('Insect_1.PNG')
print(f"Type of the image: {type(image)}")
print(f"Shape of the image array: {image.shape}")
