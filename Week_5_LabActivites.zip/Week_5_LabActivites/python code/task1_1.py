import numpy as np

#create variable arr for 10 to 19 inclusive
arr = np.arange(10, 20)

#print array
print("Array:", arr)
print("Shape:", arr.shape)
print("Dimension:", arr.ndim)
print("Data type:", arr.dtype)
